#!/bin/bash

# Check / Download / Update / Install / Run

# Root Check
if [[ $EUID -ne 0 ]]; then		          # Check if running as root
  clear
  echo "Need 'sudo'"
  exit 0
fi

builderDownloads='downloads/'
builderScripts='scripts/'
packagesArchive='lfs-packages-8.0.tar'  # LFS source package archive
packagesDownload='http://67.242.159.158/projects/lfs/files/lfs-packages-8.0.tar'

function makeFolder() {
  if [ ! -d "$1" ]; then
    `mkdir -v $1`
  fi
}

makeFolder $builderDownloads
makeFolder $builderScripts
