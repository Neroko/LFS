#/bin/bash

rm -rf $LFS_TOOLS/*
rm -rf $LFS_LOG_PATH/*
