#!/bin/bash
echo "Test"
clear
bash startover.sh
bash 5.4-binutils.sh
bash 5.5-gcc.sh
