#!/bin/bash

function prep() {
	LFS=/mnt/lfs					# LFS drive location
	LFS_SOURCES=$LFS/sources			# LFS source files location
	LFS_TOOLS=$LFS/tools				# LFS tools files location
	BIT3264=$(uname -m) &> /dev/null		# Check if 32 or 64 bit system
}

prep

function versionCheck() {
	clear
	source files/version-check.sh
}

function book() {
	LFS-BOOK-8.0.pdf
}

function mainMenu() {
	clear
	printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
	echo " Linux From Scratch"
	printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
	echo
	echo " 1: Version Check"
	echo " 2: Book"
	echo
	echo " q: Quit"
	echo
	printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
}

readOptions(){
	local choice
	read -p "Enter choice: " choice
	case $choice in
		1) versionCheck ;;
		2) book ;;
		q) exit 0;;
		*) echo -e "---Invalid Option---" && sleep 0.3
	esac
}

#trap '' SIGINT SIGQUIT SIGTSTP

while true
do

	mainMenu
	readOptions
done
