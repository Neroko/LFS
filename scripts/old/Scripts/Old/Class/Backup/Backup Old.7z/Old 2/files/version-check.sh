#!/bin/bash

export LC_ALL=C

function BASH() {
	bash --version | head -n1 | cut -d" " -f4
}
function BASHSYM() {
	MYSH=$(readlink -f /bin/sh)
	echo "/bin/sh -> $MYSH"
	echo $MYSH | grep -q bash || echo "ERROR: /bin/sh does not point to bash"
	unset MYSH
}
function BINUTILS() {
	ld --version | head -n1 | cut -d" " -f7-
}
function BISON() {
	bison --version | head -n1 | cut -d" " -f4-
}
function BISONLINK() {
	if [ -h /usr/bin/yacc ]; then
		echo "/usr/bin/yacc -> `readlink -f /usr/bin/yacc`";
	elif [ -x /usr/bin/yacc ]; then
		echo yacc is `/usr/bin/yacc --version | head -n1`
	else
		echo "yacc not found"
	fi
}
function BZIP2() {
	bzip2 --version 2>&1 < /dev/null | head -n1 | cut -d" " -f8- | cut -d"," -f1
}
function COREUTILS() {
	chown --version | head -n1 | cut -d" " -f4-
}
function DIFFUTILS() {
	diff --version | head -n1 | cut -d" " -f4-
}
function FINDUTILS() {
	find --version | head -n1 | cut -d" " -f4-
}
function GAWK() {
	gawk --version | head -n1 | cut -d" " -f3 | cut -d"," -f1
}
function GAWKLINK() {
	if [ -h /usr/bin/awk ]; then
		echo "/usr/bin/awk -> `readlink -f /usr/bin/awk`";
	elif [ -x /usr/bin/awk ]; then
		echo awk is `/usr/bin/awk --version | head -n1`
	else
		echo "awk not found"
	fi
}
function GCC() {
	gcc --version | head -n1 | cut -d" " -f4
}
function GCCGPLUS() {
	g++ --version | head -n1 | cut -d" " -f4
}
function GCCTEST() {
	echo 'int main(){}' > dummy.c && g++ -o dummy dummy.c
	if [ -x dummy ]
		then echo "G++ Compilation OK";
		else echo "G++ Compilation failed"; fi
	rm -f dummy.c dummy
}
function GLIBC() {
	ldd --version | head -n1 | cut -d" " -f5
}
function GREP() {
	grep --version | head -n1 | cut -d" " -f4
}
function GZIP() {
	gzip --version | head -n1 | cut -d" " -f2
}
function KERNEL() {
	cat /proc/version | cut -d" " -f3 | cut -d"-" -f1
}
function M4() {
	m4 --version | head -n1 | cut -d" " -f4
}
function MAKE() {
	make --version | head -n1 | cut -d" " -f3
}
function PATCH() {
	patch --version | head -n1 | cut -d" " -f3
}
function PERL() {
	echo Perl `perl -V:version` | cut -d"'" -f2
}
function SED() {
	sed --version | head -n1 | cut -d" " -f4
}
function TAR() {
	tar --version | head -n1 | cut -d" " -f4
}
function TEXINFO() {
	makeinfo --version | head -n1 | cut -d" " -f4
}
function XZ() {
	xz --version | head -n1 | cut -d" " -f4
}
function LIBRARY() {
	for lib in lib{gmp,mpfr,mpc}.la; do
		echo $lib: $(if find /usr/lib* -name $lib|
			grep -q $lib;then :;else echo not;fi) found
	done
	unset lib
}
S
clear
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'	# 210 or 221
echo " Version Check"
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
echo " Package	  Minimum	  Host"
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
printf " Bash		| 3.2		| " && BASH
printf " Bash Symbolic	|		| " && BASHSYM
printf " Binutils	| 2.17		| " && BINUTILS
printf " Bison		| 2.3		| " && BISON
printf " Bison Link	|		| " && BISONLINK
printf " Bzip2		| 1.0.4		| " && BZIP2
printf " Coreutils	| 6.9		| " && COREUTILS
printf " Diffutils	| 2.8.1		| " && DIFFUTILS
printf " Findutils	| 4.2.31	| " && FINDUTILS
printf " Gawk		| 4.0.1		| " && GAWK
printf " Gawk Link	|		| " && GAWKLINK
printf " GCC		| 4.7		| " && GCC
printf " GCC G++	|		| " && GCCGPLUS
printf " GCC Test	|		| " && GCCTEST
printf " Glibc		| 2.11		| " && GLIBC
printf " Grep		| 2.5.1a	| " && GREP
printf " Gzip		| 1.3.12	| " && GZIP
printf " Linux Kernel	| 2.6.32	| " && KERNEL
printf " M4		| 1.4.10	| " && M4
printf " Make		| 3.81		| " && MAKE
printf " Patch		| 2.5.4		| " && PATCH
printf " Perl		| 5.8.8		| " && PERL
printf " Sed		| 4.1.5		| " && SED
printf " Tar		| 1.22		| " && TAR
printf " Texinfo	| 4.7		| " && TEXINFO
printf " Xz		| 5.0.0		| " && XZ
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
echo " Library Check"
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
LIBRARY
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
read -n 1 -s -r -p "Press any key to continue"

