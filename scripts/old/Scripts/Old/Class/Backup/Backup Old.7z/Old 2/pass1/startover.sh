#!/bin/bash
echo "------------------------------"
echo "|    Emptying Tools Folder   |"
echo "------------------------------"
rm -rf $LFS/tools/*
echo "|         Complete           |"
echo "------------------------------"
