#!/bin/bash
echo "------------------------------"
echo "         LFS Setup            "
echo "------------------------------"
echo "--Setting environment for LFS..."
export LFS=/mnt/lfs
mkdir -p $LFS
mount -t ext4 /dev/sda5 $LFS
chmod a=rwx $LFS
chmod a+wt $LFS/sources
ln -sf $LFS/tools /
chown lfs $LFS/tools
chown lfs $LFS/sources
echo "------------------------------"
echo " Logged in as LFS User        "
echo "------------------------------"
su - lfs
