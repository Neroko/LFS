#!/bin/bash

function prep() {
	LFS=/mnt/lfs					# LFS drive location
	LFS_SOURCES=$LFS/sources			# LFS source files location
	LFS_TOOLS=$LFS/tools				# LFS tools files location
	LFS_ARCHIVE=$LFS_SOURCES/binutils-2.27.tar.bz2	# Archive file location
	LFS_PACKAGE=$LFS_SOURCES/binutils-2.27		# LFS unpacked package location
	LFS_BUILD=$LFS_PACKAGE/build			# LFS package build location
	LOG=$LFS_SOURCES/pass1/logs/5.4-binutils.log	# Log location
	BIT3264=$(uname -m) &> /dev/null		# Check if 32 or 64 system
}

function logCleanUp() {
	if [ ! -f "$LOG" ]; then			# If old log file doesnt exist, create it
		`touch $LOG`
	else						# Else delete old and create new
		`rm -rf $LOG`
		`touch $LOG`
	fi
}

function cleanUp() {
	if [ -d "$LFS_PACKAGE" ]; then
		`rm -rf $LFS_PACKAGE`			# Delete old package
	fi
}

function logGrab() {
	LOG_GRAB=$(grep "real" $LOG | awk '{print $2}')
}

function INFO() {
	local function_name="${FUNCNAME[1]}"
		local msg="$1"
		timeAndDate=$(date)
		echo "[$timeAndDate]  [INFO]  $msg" >> $LOG
}

function DEBUG() {
	local function_name="${FUNCNAME[1]}"
		local msg="1"
		timeAndDate=$(date)
		echo "[$timeAndDate]  [DEBUG]  $msg" >> $LOG
}

function ERROR() {
	local function_name="${FUNCNAME[1]}"
		local msg="1"
		timeAndDate=$(date)
		echo "[$timeAndDate]  [ERROR]  $msg" >> $LOG
}

spinner() {
	local pid=$1
	local delay=0.75
	local spinstr='|/-\'
	while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
		local temp=${spinstr#?}
		printf " [%c]  " "$spinstr"
		local spinstr=$temp${spinstr%"$temp"}
		sleep $delay
		printf "\b\b\b\b\b\b"
	done
	printf "    \b\b\b\b"
}

function packageExtract() {					# Extracting Files from Archive
	{ time {
		INFO "Extracting Files"
		`tar -xjf $LFS_ARCHIVE -C $LFS_SOURCES | tee -a $LOG`
		INFO "Extraction Complete"
	} } 2>&1 | tee -a $LOG &> /dev/null
}

function packageBuild() {
	{ time {
		INFO "Building Package"
		mkdir $LFS_BUILD
		cd $LFS_BUILD
		../configure				\
			--prefix=/tools			\
			--with-sysroot=$LFS		\
			--with-lib-path=/tools/lib	\
			--target=$LFS_TGT		\
			--disable-nls			\
			--disable-werror
		INFO "Build Complete"
	} } 2>&1 | tee -a $LOG &> /dev/null
}

function packageMake() {
	{ time {
		INFO "Making Package"
		cd $LFS_BUILD
		make
		INFO "Make Complete"
	} } 2>&1 | tee -a $LOG &> /dev/null
}

function package64() {
	{ time {
		cd $LFS_BUILD
		if [ $BIT3264="x86_64" ]; then
			INFO "Setting for 64 Bit"
			echo "-Making 64 Bit symlink..."
			{
			case $(uname -m) in
				x86_64) mkdir -v /tools/lib && ln -sv lib /tools/lib64 ;;
			esac
			} &> /dev/null
			INFO "Settings Complete"
		fi
	} } 2>&1 | tee -a $LOG &> /dev/null
}

function packageInstall() {
	{ time {
		INFO "Installing Package..."
		cd $LFS_BUILD
		make install
		INFO "Install Complete"
	} } 2>&1 | tee -a $LOG &> /dev/null
}

prep
logCleanUp
cleanUp
INFO "Starting..."
INFO "System: $BIT3264"
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
echo " Binutils 2.27 - Pass 1"
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
printf " - Extracting Files..."
(packageExtract) & spinner $!
echo " Complete"
printf " - Building Package..."
(packageBuild) & spinner $!
echo " Complete"
printf " - Making Package..."
(packageMake) & spinner $!
echo " Complete"
printf " - Setting for 64 Bit..."
(package64) & spinner $!
echo " Complete"
printf " - Installing Package..."
(packageInstall) & spinner $!
echo " Complete"
cleanUp
logGrab
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
echo " Complete - $LOG_GRAB"	# << FIX THIS, showing everything with word "real", should be time
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
INFO "Finished"
