#!/bin/bash

function prep() {
	LFS=/mnt/lfs					# LFS drive location
	LFS_SOURCES=$LFS/sources			# LFS source files location
	LFS_TOOLS=$LFS/tools				# LFS tools files location
	LFS_ARCHIVE=none				# Archive file location
	LFS_PACKAGE=none				# LFS unpacked package location
	LFS_BUILD=$LFS_PACKAGE/build			# LFS package build location
	LOG=$LFS_SOURCES/pass1/logs/cleaner.log		# Log location
	BIT3264=$(uname -m) &> /dev/null		# Check if 32 or 64 bit system
}

function logCleanUp() {
	if [ ! -f "$LOG" ]; then			# If log file doesnt exist, create it
		`touch $LOG`
	else						# Else delete old and create new
		`rm -rf $LOG`
		`touch $LOG`
	fi
}

function cleanUp() {
	if [ -d "$LFS_PACKAGE" ]; then
		`rm -rf $LFS_PACKAGE`			# Delete old package
	fi
}

function logGrab() {
	LOG_GRAB=$(grep "real" $LOG | awk '{print $2}')
}

function INFO() {
	local function_name="${FUNCNAME[1]}"
		local msg="$1"
		timeAndDate=$(date)
		echo "[$timeAndDate]  [INFO]  $msg" >> $LOG
}

function DEBUG() {
	local function_name="${FUNCNAME[1]}"
		local msg="1"
		timeAndDate=$(date)
		echo "[$timeAndDate]  [DEBUG]  $msg" >> $LOG
}

function ERROR() {
	local function_name="${FUNCNAME[1]}"
		local msg="1"
		timeAndDate=$(date)
		echo "[$timeAndDate]  [ERROR]  $msg" >> $LOG
}

spinner() {
	local pid=$1
	local delay=0.75
	local spinstr='|/-\'
	while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
		local temp=${spinstr#?}
		printf " [%c]  " "$spinstr"
		local spinstr=$temp${spinstr%"$temp"}
		sleep $delay
		printf "\b\b\b\b\b\b"
	done
	printf "    \b\b\b\b"
}

function cleanToolsDir() {					# Delete all files out of LFS tools folder
	{ time {
		INFO "Cleaning out LFS Tools folder..."
		`rm -rf $LFS_TOOLS/* | tee -a $LOG`
		INFO "Complete"
	} } 2>&1 | tee -a $LOG &> /dev/null
}

prep
logCleanUp
INFO "Starting..."
INFO "System: $BIT3264"
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
echo " Empty Tools Folder..."
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
echo " - Emptying..."
(cleanToolsDir) & spinner $!
echo " Complete"
logGrab
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
echo " Complete - $LOG_GRAB"
printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | sed 's/ /\o342\o226\o221/g'
INFO "Finished"
