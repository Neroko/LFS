#!/bin/bash

clear

echo "------------------------------"
echo "|        USB Copier          |"
echo "------------------------------"

function usbmount() {
	MACHINE=$(hostname)
	echo "--Mounting USB drive"
	if [ $MACHINE="evga" ]; then
		if [ ! -d "/mnt/usb" ]; then
			mkdir /mnt/usb
		fi
		MOUNTSTATUS=$(df -h | grep -c '/dev/sdb1')
		if [[ $MOUNTSTATUS = "0" ]]; then
			mount /dev/sdb1 /mnt/usb
		fi
	elif [ $MACHINE="ubuntu" ]; then
		if [ ! -d "/mnt/usb" ]; then
			mkdir /mnt/usb
		fi
		MOUNTSTATUS=$(df -h | grep -c '/dev/sdc1')
		if [[ $MOUNTSTATUS = "0" ]]; then
			mount /dev/sdc1 /mnt/usb
		fi
	else
		exit 1
	fi
}
function usbunmount() {
	read -e -i "y" -p "--Unmount USB Drive (y/n): " UNMOUNTYN
	if [[ $UNMOUNTYN == "y" || $UNMOUNTYN == "Y" ]]; then
		echo "--Unmounting USB drive"
		if [ $MACHINE="evga" ]; then
			umount /dev/sdb1
		elif [ $MACHINE="ubuntu" ]; then
			umount /dev/sdc1
		fi
	fi
}
function copyto() {
	read -p "--Enter where to copy (usb/pc): " COPYLOCATION
	if [[ $COPYLOCATION == "usb" ]]; then
		echo "--Copying LFS setup files to USB..."
		if [ -d "/home/tj/LFS" ] && [ -d "/mnt/usb/LFS" ]; then
			cp /home/tj/LFS/* /mnt/usb/LFS/
		else
			echo "--LFS setup folder not found"
		fi
		if [ -d "/mnt/lfs/sources/pass1" ] && [ -d "/mnt/usb/pass1" ]; then
			cp /mnt/lfs/sources/pass1/* /mnt/usb/pass1/
		else
			echo "--Pass 1 folder not found"
		fi
	elif [[ $COPYLOCATION == "pc" ]]; then
		echo "--Copying USB setup files to PC..."
		if [ -d "/mnt/usb/LFS" ] && [ -d "/home/tj/LFS" ]; then
			cp /mnt/usb/LFS/* /home/tj/LFS/
		else
			echo "--LFS setup folder not found"
		fi
		if [ -d "/mnt/usb/pass1" ] && [ -d "/mnt/lfs/sources/pass1" ]; then
			cp /mnt/usb/pass1/* /mnt/lfs/sources/pass1/
		else
			echo "--Pass 1 folder not found"
		fi
	else
		echo "--Not Copying"
	fi
}

usbmount
copyto
usbunmount
